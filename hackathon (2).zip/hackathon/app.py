import tkinter as tk
from tkinter import messagebox
import speech_recognition as sr

def listen_and_send_sos():
    r = sr.Recognizer()
    status_label.config(text="Listening... Say: HELP HELP", fg="blue")
    root.update()
    
    try:
        with sr.Microphone() as source:
            print("Listening...")
            r.adjust_for_ambient_noise(source, duration=1)
            audio = r.listen(source, timeout=5, phrase_time_limit=5)
        
        try:
            text = r.recognize_google(audio).lower()
            print(f"You said: {text}")
            status_label.config(text=f"You said: {text}", fg="green")
            
            if "help" in text:
                # SOS Triggered
                messagebox.showinfo("SafeLink - SOS SENT!", "SOS TRIGGERED!\n\nLocation Shared with Family!\nHelp is on the way!")
                status_label.config(text="SOS Sent Successfully!", fg="red")
                
                # Try to save file, if fails ignore it (fixes permission error)
                try:
                    with open("last_location.txt", "w") as f:
                        f.write("SOS Triggered at: User needs help! Location: Dimapur, Nagaland")
                except:
                    print("File save skipped, but SOS sent!")
            else:
                status_label.config(text=f"Heard: {text} - Say HELP", fg="orange")

        except sr.UnknownValueError:
            status_label.config(text="Could not understand, say HELP again", fg="orange")
        except Exception as e:
            status_label.config(text=f"Error: {e}", fg="red")

    except Exception as e:
        messagebox.showerror("Error", f"Mic Error: {e}")
        status_label.config(text="Mic problem", fg="red")

# UI Design
root = tk.Tk()
root.title("SafeLink - Women Safety App")
root.geometry("400x300")
root.configure(bg="white")

title = tk.Label(root, text="SafeLink", font=("Arial", 24, "bold"), bg="white", fg="#e91e63")
title.pack(pady=20)

sub = tk.Label(root, text="Your Voice is Your Safety", font=("Arial", 12), bg="white")
sub.pack()

status_label = tk.Label(root, text="Ready to listen...", font=("Arial", 11), bg="white", wraplength=350)
status_label.pack(pady=20)

btn = tk.Button(root, text="HELP BUTTON", command=listen_and_send_sos, bg="#e91e63", fg="white", font=("Arial", 14, "bold"), padx=20, pady=10)
btn.pack(pady=20)

root.mainloop()